(function(global){'use strict';
 const DOTS=__LED_DATA__,SIGNATURE='__SIGNATURE__',RADIUS=__RADIUS__,DURATION=3.9;
 const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
 const smooth=x=>{x=clamp(x);return x*x*(3-2*x);};
 function defs(id){return `<defs><linearGradient id="${id}-ink" gradientUnits="userSpaceOnUse" x1="0" y1="-100" x2="430" y2="5"><stop stop-color="#A91535"/><stop offset=".34" stop-color="#E92C2A"/><stop offset=".70" stop-color="#FF6331"/><stop offset="1" stop-color="#FFAE4F"/></linearGradient><filter id="${id}-glow" x="-20%" y="-20%" width="140%" height="140%" color-interpolation-filters="sRGB"><feGaussianBlur stdDeviation=".9"/></filter></defs>`;}
 function intensity(time,dot){return smooth((time-dot[2])/.065);}
 function cells(time,id,animated=false){return DOTS.map((d,i)=>{
  const base=`<circle data-dot="${i}" cx="${d[0]}" cy="${d[1]}" r="${RADIUS}" opacity="${animated?0:intensity(time,d).toFixed(3)}"`;
  if(!animated)return base+'/>';
  let a=d[2]/6.2,b=(d[2]+.065)/6.2;
  return base+`><animate attributeName="opacity" dur="6.2s" repeatCount="indefinite" keyTimes="0;${a.toFixed(6)};${b.toFixed(6)};1" values="0;0;1;1"/></circle>`;
 }).join('');}
 function svgAt(time,options={}){
  const id=options.id||'led',dark=options.dark!==false,glow=options.glow!==false&&dark;
  const bg=options.background===false?'':`<rect data-background="true" width="1400" height="600" fill="${dark?'#111014':'#FAF8F5'}"/>`;
  const fade=options.fade?1-smooth((time-5.75)/.4):1;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 600" width="${options.width||1400}" height="${options.height||600}" role="img" aria-labelledby="${id}-title"><title id="${id}-title">typeThis — high-density LED matrix</title>${bg}${defs(id)}<g opacity="${fade}" transform="translate(202 352) scale(1.2)"><use data-glow="true" href="#${id}-dots" filter="url(#${id}-glow)" opacity="${glow?.32:0}"/><g id="${id}-dots" fill="url(#${id}-ink)">${cells(time,id)}</g><path data-signature="true" transform="translate(459 0)" d="${SIGNATURE}" fill="${dark?'#F2EFEB':'#191719'}"/></g></svg>`;
 }
 function animatedSvg(){
  const id='led-animated';
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 600" role="img" aria-label="typeThis LED dot-matrix animation">${defs(id)}<g><animate attributeName="opacity" dur="6.2s" repeatCount="indefinite" values="1;1;0;0" keyTimes="0;.9274;.9919;1"/><g transform="translate(202 352) scale(1.2)"><use href="#${id}-dots" filter="url(#${id}-glow)" opacity=".32"/><g id="${id}-dots" fill="url(#${id}-ink)">${cells(0,id,true)}</g><path transform="translate(459 0)" d="${SIGNATURE}" fill="#F2EFEB"/></g></g></svg>`;
 }
 function mount(element,options={}){
  const el=typeof element==='string'?document.querySelector(element):element;
  if(!el)throw new Error('LED logo container not found');
  const id='led-'+Math.random().toString(36).slice(2);
  let time=0,last=0,frame=0,playing=false,speed=options.speed||1,dark=options.dark!==false,glow=options.glow!==false;
  el.innerHTML=svgAt(0,{id,dark,glow,background:options.background!==false});
  const dots=[...el.querySelectorAll('[data-dot]')],state=Array(DOTS.length).fill(0);
  function render(t){time=clamp(t,0,DURATION);DOTS.forEach((d,i)=>{let v=Math.round(intensity(time,d)*1000)/1000;if(v!==state[i]){dots[i].setAttribute('opacity',v);state[i]=v;}});options.onFrame?.(time/DURATION,time);}
  function tick(now){if(!playing)return;if(last)render(time+(now-last)*.001*speed);last=now;if(time>=DURATION){playing=false;options.onEnd?.();return;}frame=requestAnimationFrame(tick);}
  const api={play(){if(time>=DURATION)render(0);if(playing)return;playing=true;last=0;frame=requestAnimationFrame(tick);},pause(){playing=false;cancelAnimationFrame(frame);last=0;},replay(){api.pause();render(0);api.play();},seek(p){api.pause();render(clamp(p)*DURATION);},setSpeed(s){speed=clamp(Number(s),.1,4);},setDark(v){dark=!!v;el.querySelector('[data-background]')?.setAttribute('fill',dark?'#111014':'#FAF8F5');el.querySelector('[data-signature]').setAttribute('fill',dark?'#F2EFEB':'#191719');el.querySelector('[data-glow]').setAttribute('opacity',glow&&dark?.32:0);},setGlow(v){glow=!!v;el.querySelector('[data-glow]').setAttribute('opacity',glow&&dark?.32:0);},destroy(){api.pause();el.replaceChildren();},get playing(){return playing;},get progress(){return time/DURATION;}};
  if(global.matchMedia?.('(prefers-reduced-motion: reduce)').matches&&!options.forceMotion)render(DURATION);else if(options.autoplay!==false)api.play();
  return api;
 }
 const api={mount,svgAt,animatedSvg,DOTS,SIGNATURE,DURATION,RADIUS,intensity};if(typeof module!=='undefined'&&module.exports)module.exports=api;else global.TypeLED=api;
})(typeof window!=='undefined'?window:globalThis);
