/* typeThis / Ember brush. Dependency-free SVG animation. */
(function (global) {
  'use strict';
  const SIGNATURE = 'M72.88065843621399 -114.33744855967078H113.20164609053498V-138.0H2.6502057613168724V-114.33744855967078H44.48559670781893V0.0H72.88065843621399ZM125.14567901234568 -138.0V0.0H151.6477366255144V-61.333333333333336C151.6477366255144 -73.06995884773663 160.16625514403293 -81.39917695473251 172.09218106995885 -81.39917695473251C177.9604938271605 -81.39917695473251 182.31440329218105 -79.31687242798354 185.3432098765432 -75.1522633744856C187.80411522633744 -71.7448559670782 188.37201646090534 -68.90534979423869 188.37201646090534 -62.46913580246913V0.0H214.8740740740741V-68.52674897119341C214.8740740740741 -81.20987654320987 211.46666666666667 -90.29629629629629 204.4625514403292 -96.16460905349794C198.59423868312757 -101.08641975308642 190.07572016460904 -103.92592592592592 181.55720164609053 -103.92592592592592C168.4954732510288 -103.92592592592592 159.0304526748971 -98.81481481481481 151.6477366255144 -87.45679012345678V-138.0ZM264.11028806584363 -102.22222222222223H237.60823045267492V0.0H264.11028806584363ZM264.11028806584363 -138.0H237.60823045267492V-114.33744855967078H264.11028806584363ZM369.94732510288065 -69.28395061728395C369.56872427983535 -90.8641975308642 352.9102880658436 -103.92592592592592 325.46172839506175 -103.92592592592592C299.5275720164609 -103.92592592592592 283.43703703703704 -90.8641975308642 283.43703703703704 -69.85185185185185C283.43703703703704 -63.03703703703704 285.519341563786 -57.16872427983539 289.116049382716 -53.193415637860085C292.71275720164607 -49.59670781893004 295.93086419753087 -47.89300411522634 305.7744855967078 -44.674897119341566L337.3876543209876 -34.83127572016461C344.0131687242798 -32.748971193415635 346.2847736625514 -30.666666666666668 346.2847736625514 -26.502057613168724C346.2847736625514 -20.25514403292181 338.9020576131687 -16.469135802469136 326.59753086419755 -16.469135802469136C319.59341563786006 -16.469135802469136 314.2930041152263 -17.604938271604937 310.88559670781893 -20.06584362139918C308.04609053497944 -22.14814814814815 306.9102880658436 -24.23045267489712 305.7744855967078 -29.720164609053498H279.840329218107C280.59753086419755 -7.193415637860082 297.06666666666666 4.3539094650205765 328.1119341563786 4.3539094650205765C342.3094650205761 4.3539094650205765 353.09958847736624 1.3251028806584362 360.67160493827157 -4.732510288065844C368.24362139917696 -10.790123456790123 372.78683127572015 -20.25514403292181 372.78683127572015 -30.2880658436214C372.78683127572015 -43.53909465020576 366.16131687242796 -52.05761316872428 352.720987654321 -56.03292181069959L319.2148148148148 -65.6872427983539C311.8320987654321 -67.95884773662551 309.93909465020573 -69.47325102880659 309.93909465020573 -73.63786008230453C309.93909465020573 -79.31687242798354 315.99670781893 -83.10288065843622 325.2724279835391 -83.10288065843622C337.9555555555555 -83.10288065843622 344.20246913580246 -78.559670781893 344.3917695473251 -69.28395061728395Z';
  const DRAW_DURATION = 3.85;
  // Cubic Bezier centre lines, in logo coordinates. Timing is in seconds.
  const raw = [
    {name:'t-stem',start:.14,duration:.56,width:27,tip:.77,points:[[54,-142],[50,-108,34,-48,40,-23],[46,0,71,3,94,-19]]},
    {name:'y-bowl',start:.69,duration:.49,width:27,tip:.8,points:[[123,-92],[113,-56,109,-26,133,-19],[157,-12,172,-48,184,-94]]},
    {name:'y-loop',start:1.16,duration:.68,width:26,tip:.64,points:[[184,-94],[171,-42,175,18,142,49],[115,76,78,65,90,39],[105,13,178,26,235,-23]]},
    {name:'p-stem',start:1.84,duration:.34,width:27,tip:.72,points:[[249,-91],[240,-51,231,8,224,48]]},
    {name:'p-bowl',start:2.16,duration:.58,width:26,tip:.8,points:[[243,-60],[265,-106,308,-106,315,-71],[323,-29,282,10,251,-13],[281,7,317,-8,337,-34]]},
    {name:'e-loop',start:2.72,duration:.68,width:27,tip:.45,points:[[337,-34],[374,-43,406,-73,388,-92],[370,-112,342,-86,335,-56],[322,-14,347,9,383,-5],[397,-10,409,-20,419,-32]]},
    {name:'t-cross',start:3.48,duration:.31,width:23,tip:.42,points:[[15,-94],[39,-101,68,-97,96,-101]]}
  ];
  const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
  const smooth=x=>{x=clamp(x);return x*x*(3-2*x);};
  const num=x=>Math.round(x*100)/100;
  const pt=p=>`${num(p.x)} ${num(p.y)}`;
  const bezier=(a,b,c,d,t)=>{const v=1-t;return v*v*v*a+3*v*v*t*b+3*v*t*t*c+t*t*t*d;};
  function sample(s) {
    let from=s.points[0], result=[{x:from[0],y:from[1],length:0}],total=0;
    for(const c of s.points.slice(1)) {
      for(let i=1;i<=64;i++) {
        const t=i/64,p={x:bezier(from[0],c[0],c[2],c[4],t),y:bezier(from[1],c[1],c[3],c[5],t)};
        const old=result[result.length-1];total+=Math.hypot(p.x-old.x,p.y-old.y);p.length=total;result.push(p);
      }
      from=[c[4],c[5]];
    }
    result.forEach((p,i)=>{
      const before=result[Math.max(0,i-1)],after=result[Math.min(result.length-1,i+1)];
      const dx=after.x-before.x,dy=after.y-before.y,l=Math.hypot(dx,dy)||1;
      p.tx=dx/l;p.ty=dy/l;p.u=p.length/total;
      // A soft elliptical nib: downstrokes carry more ink than upstrokes.
      const angle=Math.abs(p.ty*.92+p.tx*.39);
      const nib=.69+.31*angle;
      const entry=.72+.28*smooth(p.u/.085);
      const terminal=1-(1-s.tip)*smooth((p.u-.87)/.13);
      const breath=1+.055*Math.sin(p.u*Math.PI*2-.5);
      p.radius=s.width*.5*nib*entry*terminal*breath;
    });
    return {...s,samples:result,length:total};
  }
  const strokes=raw.map(sample);
  function interpolate(a,b,t) {
    const p={};for(const k of ['x','y','tx','ty','radius','u','length'])p[k]=a[k]+(b[k]-a[k])*t;return p;
  }
  function pointsAt(s,progress) {
    const points=[],count=128;let j=1;
    for(let i=0;i<count;i++){
      const distance=s.length*clamp(progress)*i/(count-1);
      while(j<s.samples.length-1&&s.samples[j].length<distance)j++;
      const a=s.samples[j-1],b=s.samples[j];
      points.push(interpolate(a,b,(distance-a.length)/(b.length-a.length)));
    }
    return points;
  }
  function outline(s,progress) {
    const points=pointsAt(s,progress);
    const last=points[points.length-1],left=[],right=[],startup=smooth(progress/.025);
    const head=.91+.09*smooth((progress-.94)/.06);
    for(const p of points) {
      // The moving front carries slightly less pressure, then fills naturally.
      const wet=head+(1-head)*smooth((last.length-p.length)/14);
      const r=p.radius*wet*startup;
      left.push({x:p.x-p.ty*r,y:p.y+p.tx*r});right.push({x:p.x+p.ty*r,y:p.y-p.tx*r});
    }
    const l=left[left.length-1],r=right[right.length-1],cap=last.radius*head*startup;
    let d='M'+pt(left[0])+left.slice(1).map(p=>'L'+pt(p)).join('');
    // Forward semicircle cap, built with cubic tangents (no polygonal nib).
    const tip={x:last.x+last.tx*cap,y:last.y+last.ty*cap},k=.55228475;
    d+=`C${num(l.x+last.tx*cap*k)} ${num(l.y+last.ty*cap*k)} ${num(tip.x-last.ty*cap*k)} ${num(tip.y+last.tx*cap*k)} ${pt(tip)}`;
    d+=`C${num(tip.x+last.ty*cap*k)} ${num(tip.y-last.tx*cap*k)} ${num(r.x+last.tx*cap*k)} ${num(r.y+last.ty*cap*k)} ${pt(r)}`;
    d+=right.slice(0,-1).reverse().map(p=>'L'+pt(p)).join('');
    const first=points[0],rr=first.radius*(head+(1-head)*smooth(last.length/14))*startup,back={x:first.x-first.tx*rr,y:first.y-first.ty*rr};
    d+=`C${num(right[0].x-first.tx*rr*k)} ${num(right[0].y-first.ty*rr*k)} ${num(back.x+first.ty*rr*k)} ${num(back.y-first.tx*rr*k)} ${pt(back)}`;
    d+=`C${num(back.x-first.ty*rr*k)} ${num(back.y+first.tx*rr*k)} ${num(left[0].x-first.tx*rr*k)} ${num(left[0].y-first.ty*rr*k)} ${pt(left[0])}Z`;
    return d;
  }
  function progress(s,time) {
    const p=clamp((time-s.start)/s.duration);
    // Almost constant velocity through the body, gentle acceleration at the ends.
    return p-Math.sin(p*2*Math.PI)*.085;
  }
  function defs(id) {
    return `<defs><linearGradient id="${id}-ink" gradientUnits="userSpaceOnUse" x1="0" y1="-105" x2="432" y2="5"><stop offset="0" stop-color="#77112B"/><stop offset=".25" stop-color="#B51B25"/><stop offset=".55" stop-color="#E63920"/><stop offset=".82" stop-color="#FF702B"/><stop offset="1" stop-color="#FFA447"/></linearGradient></defs>`;
  }
  function svgAt(time,options={}) {
    const id=options.id||'brush',dark=!!options.dark,ink=dark?'#F5F1EC':'#191719';
    const bg=options.background===false?'':`<rect width="1400" height="600" fill="${dark?'#171416':'#FAF8F5'}"/>`;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 600" width="${options.width||1400}" height="${options.height||600}" role="img" aria-label="typeThis, drawn with flowing red-orange brush strokes">${bg}${defs(id)}<g transform="translate(202 352) scale(1.2)"><g fill="url(#${id}-ink)">${strokes.map(s=>`<path data-stroke="${s.name}" d="${outline(s,progress(s,time))}"/>`).join('')}</g><path data-signature="true" transform="translate(459 0)" d="${SIGNATURE}" fill="${ink}"/></g></svg>`;
  }
  function mount(element,options={}) {
    const el=typeof element==='string'?document.querySelector(element):element;
    if(!el)throw new Error('typeThis target element was not found');
    let time=0,last=0,playing=false,frame=0,speed=options.speed||1,dark=!!options.dark;
    const id='typebrush-'+Math.random().toString(36).slice(2);
    el.innerHTML=svgAt(0,{id,background:options.background!==false,dark});
    const paths=[...el.querySelectorAll('[data-stroke]')];
    function render(t) {
      time=clamp(t,0,DRAW_DURATION);paths.forEach((p,i)=>p.setAttribute('d',outline(strokes[i],progress(strokes[i],time))));
      options.onFrame?.(time/DRAW_DURATION,time);
    }
    function tick(now) {
      if(!playing)return;
      if(last)render(time+(now-last)*.001*speed);last=now;
      if(time>=DRAW_DURATION){playing=false;options.onEnd?.();return;}
      frame=requestAnimationFrame(tick);
    }
    const api={
      play(){if(time>=DRAW_DURATION)render(0);if(playing)return;playing=true;last=0;frame=requestAnimationFrame(tick);},
      pause(){playing=false;cancelAnimationFrame(frame);last=0;},
      replay(){api.pause();render(0);api.play();},
      seek(progress){api.pause();render(clamp(progress)*DRAW_DURATION);},
      setSpeed(value){speed=clamp(Number(value),.1,4);},
      setDark(value){dark=!!value;el.querySelector('svg>rect')?.setAttribute('fill',dark?'#171416':'#FAF8F5');el.querySelector('[data-signature]').setAttribute('fill',dark?'#F5F1EC':'#191719');},
      destroy(){api.pause();el.replaceChildren();},
      get progress(){return time/DRAW_DURATION;},get playing(){return playing;}
    };
    const reduced=global.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if(reduced&&!options.forceMotion)render(DRAW_DURATION);else if(options.autoplay!==false)api.play();
    return api;
  }
  const api={mount,svgAt,strokes,outline,progress,defs,SIGNATURE,DRAW_DURATION};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  else global.TypeBrush=api;
})(typeof window!=='undefined'?window:globalThis);
