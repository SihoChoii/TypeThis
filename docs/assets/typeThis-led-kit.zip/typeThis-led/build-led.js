const fs=require('fs'),path=require('path'),sharp=require('sharp');
const B=require('./source-brush.js'),P=__dirname;
const pitch=2.6,radius=.94,total=6.2;
const NUM=x=>Math.round(x*10000)/10000;
function inverseProgress(target){let lo=0,hi=1;for(let i=0;i<25;i++){let p=(lo+hi)/2,v=p-Math.sin(p*2*Math.PI)*.085;if(v<target)lo=p;else hi=p;}return (lo+hi)/2;}
function closestU(s,x,y){let best=1e9,u=0;for(let i=1;i<s.samples.length;i++){let a=s.samples[i-1],b=s.samples[i],dx=b.x-a.x,dy=b.y-a.y,l=dx*dx+dy*dy,t=Math.max(0,Math.min(1,((x-a.x)*dx+(y-a.y)*dy)/l)),d=(x-a.x-t*dx)**2+(y-a.y-t*dy)**2;if(d<best){best=d;u=a.u+(b.u-a.u)*t;}}return u;}
(async()=>{
 const maps=[];
 for(const s of B.strokes){const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="-20 -170 470 270" width="1410" height="810"><path d="${B.outline(s,1)}" fill="white"/></svg>`;maps.push(await sharp(Buffer.from(svg)).ensureAlpha().raw().toBuffer());}
 const dots=[];
 for(let row=-64;row<=32;row++)for(let col=0;col<=169;col++){
  let x=NUM(col*pitch),y=NUM(row*pitch),on=Infinity;
  const px=Math.floor((x+20)*3),py=Math.floor((y+170)*3),offset=(py*1410+px)*4+3;
  for(let j=0;j<B.strokes.length;j++)if(maps[j][offset]>=128){const s=B.strokes[j],u=closestU(s,x,y);on=Math.min(on,s.start+s.duration*inverseProgress(u));}
  if(Number.isFinite(on))dots.push([x,y,NUM(on)]);
 }
 dots.sort((a,b)=>a[2]-b[2]);
 fs.writeFileSync(path.join(P,'led-data.json'),JSON.stringify({pitch,radius,dots}));
 const template=fs.readFileSync(path.join(P,'engine-template.js'),'utf8');
 const engine=template.replace('__LED_DATA__',JSON.stringify(dots)).replace('__SIGNATURE__',B.SIGNATURE).replace('__RADIUS__',radius);
 fs.writeFileSync(path.join(P,'type-led.js'),engine);
 const L=require('./type-led.js');
 fs.writeFileSync(path.join(P,'typeThis-led-static.svg'),L.svgAt(4,{background:false,dark:false,glow:false}));
 fs.writeFileSync(path.join(P,'typeThis-led-static-dark.svg'),L.svgAt(4,{background:false,dark:true}));
 fs.writeFileSync(path.join(P,'typeThis-led-animated.svg'),L.animatedSvg());
 let html=fs.readFileSync(path.join(P,'playground-template.html'),'utf8').replace('/*__ENGINE__*/',engine).replace('__DOT_COUNT__',dots.length.toLocaleString('en-US'));
 fs.writeFileSync(path.join(P,'typeThis-led-playground.html'),html);
 await sharp(Buffer.from(L.svgAt(4,{width:2240,height:960}))).png().toFile(path.join(P,'typeThis-led-preview.png'));
 await sharp(Buffer.from(L.svgAt(4,{width:2240,height:960,dark:false,glow:false}))).png().toFile(path.join(P,'typeThis-led-light-preview.png'));
 fs.mkdirSync(path.join(P,'.frames'),{recursive:true});
 let cursor=0;const frames=Math.round(total*60);
 async function worker(){while(cursor<frames){const f=cursor++,t=f/60;await sharp(Buffer.from(L.svgAt(t,{fade:true}))).png().toFile(path.join(P,'.frames',String(f).padStart(4,'0')+'.png'));}}
 await Promise.all(Array.from({length:4},worker));
 console.log(JSON.stringify({dots:dots.length,pitch,radius,frames,duration:total}));
})();
