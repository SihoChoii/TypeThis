# typeThis — LED dot matrix

A high-density LED interpretation of the selected brush lettering: 4,635 circular emitters on a regular grid. The red-to-orange gradient is continuous across the letters, and This remains a solid shared signature.

## Use

Open `typeThis-led-playground.html` for replay, a timeline scrubber, speed controls, a glow toggle, and light/dark backgrounds. The page is self-contained and needs no server.

### Artwork

- `typeThis-led-static.svg`: transparent SVG, dark This lettering, for light backgrounds.
- `typeThis-led-static-dark.svg`: transparent SVG, light This lettering and subtle LED glow, for dark backgrounds.
- `typeThis-led-animated.svg`: transparent looping SVG for dark backgrounds. The lights follow the brush drawing order, hold, and fade before restarting.
- `typeThis-led-preview.png`: 2240 × 960 dark preview.
- `typeThis-led-light-preview.png`: 2240 × 960 light preview.
- `typeThis-led-preview.mp4`: 1400 × 600, 60 fps animation.
- `typeThis-led-preview.gif`: looping animated preview.

### Reusable animation

```html
<div id="logo"></div>
<script src="type-led.js"></script>
<script>
const logo = TypeLED.mount('#logo', {
  autoplay: true,
  background: false,
  dark: true,
  glow: true,
  speed: 1
});
// logo.replay();
// logo.pause();
// logo.play();
// logo.seek(0.5);
// logo.setSpeed(0.5);
// logo.setGlow(false);
// logo.setDark(false);
// logo.destroy();
</script>
```

The HTML/JS entrance runs for 3.9 seconds and plays once. It respects reduced-motion preferences by showing the finished artwork immediately; users may still choose replay. The standalone animated SVG and GIF repeat every 6.2 seconds. A static SVG is included for nonanimated use.

Each emitter retains its exact circular shape; the animation changes intensity rather than cutting dots with a moving mask. Dot spacing is 2.6 logo units, with a radius of 0.94 units. Dots use vector coordinates and do not depend on a fixed export resolution. The SVGs contain no font dependencies or embedded raster images.

## Build

`build-led.js` derives emitters and onset times from `source-brush.js`, then generates the dependency-free `type-led.js`, the SVGs, the interactive HTML, and animation frames. Run with Node.js and the `sharp` package installed. Preview video and GIF encoding uses ffmpeg. Templates and the generated LED data are included.

## Verification

The vector renders were visually inspected in light and dark modes and at intermediate drawing stages. Checks cover a regular nonoverlapping grid, unique emitter positions, ordered onset times, all lights off at the start and on at completion, finite SVG output, preserved This geometry, and valid embedded script syntax. Browser interaction was not exercised in this build environment.
